import api from "./api";

const BASE = "/api/analytics";

export const getDashboardAnalytics = () =>
    api.get(`${BASE}/dashboard`);