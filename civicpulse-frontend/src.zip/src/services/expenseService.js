import api from "./api";

const BASE = "/api/expenses";

export const getExpenses = () => api.get(BASE);

export const getExpense = (id) => api.get(`${BASE}/${id}`);

export const createExpense = (data) => api.post(BASE, data);

export const deleteExpense = (id) => api.delete(`${BASE}/${id}`);

export const getByBudget = (id) => api.get(`${BASE}/budget/${id}`);

export const getByDepartment = (department) =>
    api.get(`${BASE}/department/${department}`);

export const getByCategory = (category) =>
    api.get(`${BASE}/category/${category}`);