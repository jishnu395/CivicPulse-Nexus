import api from "./api";

const BASE = "/api/welfare-applications";

export const getApplications = () =>
    api.get(BASE);

export const getApplication = (id) =>
    api.get(`${BASE}/${id}`);

export const createApplication = (data) =>
    api.post(BASE, data);

export const approveApplication = (id) =>
    api.put(`${BASE}/${id}/approve`);

export const rejectApplication = (id) =>
    api.put(`${BASE}/${id}/reject`);

export const getApplicationsByCitizen = (citizenId) =>
    api.get(`${BASE}/citizen/${citizenId}`);

export const getApplicationsByStatus = (status) =>
    api.get(`${BASE}/status/${status}`);