import api from "./api";

const BASE = "/api/beneficiaries";

export const getBeneficiaries = () =>
    api.get(BASE);

export const getBeneficiary = (id) =>
    api.get(`${BASE}/${id}`);

export const createBeneficiary = (data) =>
    api.post(BASE, data);

export const updateBeneficiary = (id, data) =>
    api.put(`${BASE}/${id}`, data);

export const deleteBeneficiary = (id) =>
    api.delete(`${BASE}/${id}`);

export const verifyEligibility = (id) =>
    api.get(`${BASE}/${id}/eligibility`);