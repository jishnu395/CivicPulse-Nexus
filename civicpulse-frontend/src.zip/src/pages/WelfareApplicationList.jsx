import { useEffect, useState } from "react";
import {
    Box,
    Button,
    Chip,
    Dialog,
    DialogActions,
    DialogContent,
    DialogTitle,
    MenuItem,
    Paper,
    Stack,
    TextField,
    Typography
} from "@mui/material";
import { DataGrid } from "@mui/x-data-grid";
import DashboardLayout from "../layouts/DashboardLayout";
import {
    createApplication,
    getApplications,
    approveApplication,
    rejectApplication
} from "../services/welfareApplicationService";
import { toast } from "react-toastify";

export default function WelfareApplicationList() {

    const empty = {
        citizenId: "",
        beneficiaryId: "",
        schemeId: "",
        remarks: ""
    };

    const [rows, setRows] = useState([]);
    const [open, setOpen] = useState(false);
    const [form, setForm] = useState(empty);

    const load = async () => {

        const res = await getApplications();

        setRows(res.data);

    };

    useEffect(() => {

        load();

    }, []);

    const save = async () => {

        try {

            await createApplication(form);

            toast.success("Application Submitted");

            setOpen(false);

            setForm(empty);

            load();

        } catch {

            toast.error("Operation Failed");

        }

    };

    const approve = async (id) => {

        await approveApplication(id);

        toast.success("Approved");

        load();

    };

    const reject = async (id) => {

        await rejectApplication(id);

        toast.success("Rejected");

        load();

    };

    const columns = [

        {
            field: "id",
            headerName: "ID",
            width: 70
        },

        {
            field: "citizenId",
            headerName: "Citizen",
            flex: 1
        },

        {
            field: "beneficiaryId",
            headerName: "Beneficiary",
            flex: 1
        },

        {
            field: "schemeId",
            headerName: "Scheme",
            flex: 1
        },

        {
            field: "appliedDate",
            headerName: "Applied",
            flex: 1
        },

        {
            field: "status",
            headerName: "Status",
            width: 150,
            renderCell: (params) => {

                let color = "warning";

                if (params.value === "APPROVED")
                    color = "success";

                if (params.value === "REJECTED")
                    color = "error";

                return (
                    <Chip
                        label={params.value}
                        color={color}
                    />
                );

            }
        },

        {
            field: "actions",
            width: 220,
            renderCell: (params) => (

                <Stack
                    direction="row"
                    spacing={1}
                >

                    <Button
                        size="small"
                        variant="contained"
                        color="success"
                        disabled={params.row.status !== "PENDING"}
                        onClick={() => approve(params.row.id)}
                    >
                        Approve
                    </Button>

                    <Button
                        size="small"
                        variant="contained"
                        color="error"
                        disabled={params.row.status !== "PENDING"}
                        onClick={() => reject(params.row.id)}
                    >
                        Reject
                    </Button>

                </Stack>

            )
        }

    ];

    return (

        <DashboardLayout>

            <Paper sx={{ p: 3 }}>

                <Stack
                    direction="row"
                    justifyContent="space-between"
                    mb={2}
                >

                    <Typography variant="h5">

                        Welfare Applications

                    </Typography>

                    <Button
                        variant="contained"
                        onClick={() => setOpen(true)}
                    >
                        New Application
                    </Button>

                </Stack>

                <Box sx={{ height: 620 }}>

                    <DataGrid
                        rows={rows}
                        columns={columns}
                        pageSizeOptions={[10]}
                    />

                </Box>

            </Paper>

            <Dialog
                open={open}
                onClose={() => setOpen(false)}
                maxWidth="sm"
                fullWidth
            >

                <DialogTitle>

                    Apply for Welfare Scheme

                </DialogTitle>

                <DialogContent>

                    <Stack spacing={2} mt={1}>

                        <TextField
                            label="Citizen ID"
                            value={form.citizenId}
                            onChange={(e) =>
                                setForm({
                                    ...form,
                                    citizenId: e.target.value
                                })
                            }
                        />

                        <TextField
                            label="Beneficiary ID"
                            value={form.beneficiaryId}
                            onChange={(e) =>
                                setForm({
                                    ...form,
                                    beneficiaryId: e.target.value
                                })
                            }
                        />

                        <TextField
                            label="Scheme ID"
                            value={form.schemeId}
                            onChange={(e) =>
                                setForm({
                                    ...form,
                                    schemeId: e.target.value
                                })
                            }
                        />

                        <TextField
                            multiline
                            rows={4}
                            label="Remarks"
                            value={form.remarks}
                            onChange={(e) =>
                                setForm({
                                    ...form,
                                    remarks: e.target.value
                                })
                            }
                        />

                    </Stack>

                </DialogContent>

                <DialogActions>

                    <Button onClick={() => setOpen(false)}>
                        Cancel
                    </Button>

                    <Button
                        variant="contained"
                        onClick={save}
                    >
                        Submit
                    </Button>

                </DialogActions>

            </Dialog>

        </DashboardLayout>

    );

}