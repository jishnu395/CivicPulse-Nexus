import { useEffect, useState } from "react";
import {
    Box,
    Button,
    Dialog,
    DialogActions,
    DialogContent,
    DialogTitle,
    MenuItem,
    Paper,
    Stack,
    TextField,
    Typography
} from "@mui/material";
import { DataGrid } from "@mui/x-data-grid";
import DashboardLayout from "../layouts/DashboardLayout";
import {
    createFundDistribution,
    getFundDistributions,
    completeDistribution,
    failDistribution
} from "../services/fundDistributionService";
import { toast } from "react-toastify";

const statuses = [
    "PENDING",
    "COMPLETED",
    "FAILED"
];

export default function FundDistributionList() {

    const [rows, setRows] = useState([]);

    const [open, setOpen] = useState(false);

    const [form, setForm] = useState({
        citizenId: "",
        beneficiaryId: "",
        amount: "",
        purpose: ""
    });

    const load = async () => {

        const res = await getFundDistributions();

        setRows(res.data);

    };

    useEffect(() => {

        load();

    }, []);

    const save = async () => {

        try {

            await createFundDistribution(form);

            toast.success("Distribution Created");

            setOpen(false);

            setForm({
                citizenId: "",
                beneficiaryId: "",
                amount: "",
                purpose: ""
            });

            load();

        } catch {

            toast.error("Failed");

        }

    };

    const complete = async (id) => {

        await completeDistribution(id);

        toast.success("Completed");

        load();

    };

    const fail = async (id) => {

        await failDistribution(id);

        toast.success("Marked Failed");

        load();

    };

    const columns = [

        {
            field: "id",
            headerName: "ID",
            width: 70
        },

        {
            field: "citizenId",
            headerName: "Citizen",
            flex: 1
        },

        {
            field: "beneficiaryId",
            headerName: "Beneficiary",
            flex: 1
        },

        {
            field: "amount",
            headerName: "Amount",
            flex: 1
        },

        {
            field: "purpose",
            headerName: "Purpose",
            flex: 1
        },

        {
            field: "status",
            headerName: "Status",
            flex: 1
        },

        {
            field: "action",
            width: 220,
            renderCell: (params) => (

                <Stack direction="row" spacing={1}>

                    <Button
                        size="small"
                        variant="contained"
                        onClick={() => complete(params.row.id)}
                        disabled={params.row.status === "COMPLETED"}
                    >
                        Complete
                    </Button>

                    <Button
                        size="small"
                        color="error"
                        variant="contained"
                        onClick={() => fail(params.row.id)}
                        disabled={params.row.status === "FAILED"}
                    >
                        Fail
                    </Button>

                </Stack>

            )
        }

    ];

    return (

        <DashboardLayout>

            <Paper sx={{ p: 3 }}>

                <Stack
                    direction="row"
                    justifyContent="space-between"
                    mb={2}
                >

                    <Typography variant="h5">

                        Fund Distribution

                    </Typography>

                    <Button
                        variant="contained"
                        onClick={() => setOpen(true)}
                    >

                        New Distribution

                    </Button>

                </Stack>

                <Box sx={{ height: 600 }}>

                    <DataGrid
                        rows={rows}
                        columns={columns}
                        pageSizeOptions={[10]}
                    />

                </Box>

            </Paper>

            <Dialog
                open={open}
                onClose={() => setOpen(false)}
            >

                <DialogTitle>

                    New Distribution

                </DialogTitle>

                <DialogContent>

                    <Stack spacing={2} mt={1}>

                        <TextField
                            label="Citizen ID"
                            value={form.citizenId}
                            onChange={(e) =>
                                setForm({
                                    ...form,
                                    citizenId: e.target.value
                                })
                            }
                        />

                        <TextField
                            label="Beneficiary ID"
                            value={form.beneficiaryId}
                            onChange={(e) =>
                                setForm({
                                    ...form,
                                    beneficiaryId: e.target.value
                                })
                            }
                        />

                        <TextField
                            label="Amount"
                            type="number"
                            value={form.amount}
                            onChange={(e) =>
                                setForm({
                                    ...form,
                                    amount: e.target.value
                                })
                            }
                        />

                        <TextField
                            label="Purpose"
                            value={form.purpose}
                            onChange={(e) =>
                                setForm({
                                    ...form,
                                    purpose: e.target.value
                                })
                            }
                        />

                    </Stack>

                </DialogContent>

                <DialogActions>

                    <Button onClick={() => setOpen(false)}>
                        Cancel
                    </Button>

                    <Button
                        variant="contained"
                        onClick={save}
                    >
                        Save
                    </Button>

                </DialogActions>

            </Dialog>

        </DashboardLayout>

    );

}