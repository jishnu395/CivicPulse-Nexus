import { useEffect, useState } from "react";
import {
    Box,
    Button,
    Dialog,
    DialogActions,
    DialogContent,
    DialogTitle,
    MenuItem,
    Paper,
    Stack,
    TextField,
    Typography
} from "@mui/material";
import { DataGrid } from "@mui/x-data-grid";
import DashboardLayout from "../layouts/DashboardLayout";
import {
    createExpense,
    deleteExpense,
    getExpenses
} from "../services/expenseService";
import { getBudgets } from "../services/budgetService";
import { toast } from "react-toastify";

const categories = [
    "INFRASTRUCTURE",
    "HEALTHCARE",
    "EDUCATION",
    "PENSION",
    "SUBSIDY",
    "ADMINISTRATION",
    "OTHER"
];

export default function ExpenseList() {

    const [expenses, setExpenses] = useState([]);
    const [budgets, setBudgets] = useState([]);

    const [open, setOpen] = useState(false);

    const [form, setForm] = useState({
        budgetId: "",
        department: "",
        category: "",
        description: "",
        amount: ""
    });

    const load = async () => {

        const e = await getExpenses();
        setExpenses(e.data);

        const b = await getBudgets();
        setBudgets(b.data);

    };

    useEffect(() => {
        load();
    }, []);

    const save = async () => {

        try {

            await createExpense(form);

            toast.success("Expense Added");

            setOpen(false);

            setForm({
                budgetId: "",
                department: "",
                category: "",
                description: "",
                amount: ""
            });

            load();

        } catch {

            toast.error("Failed");

        }

    };

    const remove = async (id) => {

        await deleteExpense(id);

        toast.success("Deleted");

        load();

    };

    const columns = [

        {
            field: "id",
            headerName: "ID",
            width: 80
        },

        {
            field: "department",
            headerName: "Department",
            flex: 1
        },

        {
            field: "category",
            headerName: "Category",
            flex: 1
        },

        {
            field: "description",
            headerName: "Description",
            flex: 1
        },

        {
            field: "amount",
            headerName: "Amount",
            flex: 1
        },

        {
            field: "createdAt",
            headerName: "Created",
            flex: 1
        },

        {
            field: "action",
            width: 120,
            renderCell: (params) => (

                <Button
                    color="error"
                    variant="contained"
                    onClick={() => remove(params.row.id)}
                >
                    Delete
                </Button>

            )
        }

    ];

    return (

        <DashboardLayout>

            <Paper sx={{ p: 3 }}>

                <Stack
                    direction="row"
                    justifyContent="space-between"
                    mb={2}
                >

                    <Typography variant="h5">

                        Expense Management

                    </Typography>

                    <Button
                        variant="contained"
                        onClick={() => setOpen(true)}
                    >

                        Add Expense

                    </Button>

                </Stack>

                <Box sx={{ height: 600 }}>

                    <DataGrid
                        rows={expenses}
                        columns={columns}
                        pageSizeOptions={[10]}
                    />

                </Box>

            </Paper>

            <Dialog
                open={open}
                onClose={() => setOpen(false)}
            >

                <DialogTitle>

                    New Expense

                </DialogTitle>

                <DialogContent>

                    <Stack spacing={2} mt={1}>

                        <TextField
                            select
                            label="Budget"
                            value={form.budgetId}
                            onChange={(e) =>
                                setForm({
                                    ...form,
                                    budgetId: e.target.value
                                })
                            }
                        >

                            {
                                budgets.map((b) => (

                                    <MenuItem
                                        key={b.id}
                                        value={b.id}
                                    >
                                        {b.department}
                                    </MenuItem>

                                ))
                            }

                        </TextField>

                        <TextField
                            label="Department"
                            value={form.department}
                            onChange={(e) =>
                                setForm({
                                    ...form,
                                    department: e.target.value
                                })
                            }
                        />

                        <TextField
                            select
                            label="Category"
                            value={form.category}
                            onChange={(e) =>
                                setForm({
                                    ...form,
                                    category: e.target.value
                                })
                            }
                        >

                            {
                                categories.map((c) => (

                                    <MenuItem
                                        key={c}
                                        value={c}
                                    >
                                        {c}
                                    </MenuItem>

                                ))
                            }

                        </TextField>

                        <TextField
                            label="Description"
                            value={form.description}
                            onChange={(e) =>
                                setForm({
                                    ...form,
                                    description: e.target.value
                                })
                            }
                        />

                        <TextField
                            type="number"
                            label="Amount"
                            value={form.amount}
                            onChange={(e) =>
                                setForm({
                                    ...form,
                                    amount: e.target.value
                                })
                            }
                        />

                    </Stack>

                </DialogContent>

                <DialogActions>

                    <Button onClick={() => setOpen(false)}>
                        Cancel
                    </Button>

                    <Button
                        variant="contained"
                        onClick={save}
                    >
                        Save
                    </Button>

                </DialogActions>

            </Dialog>

        </DashboardLayout>

    );

}