import { useEffect, useState } from "react";
import {
    Box,
    Paper,
    Typography
} from "@mui/material";
import { DataGrid } from "@mui/x-data-grid";
import DashboardLayout from "../layouts/DashboardLayout";
import { getAuditLogs } from "../services/auditService";

export default function AuditLogs() {

    const [rows, setRows] = useState([]);

    useEffect(() => {

        load();

    }, []);

    const load = async () => {

        const res = await getAuditLogs();

        setRows(res.data);

    };

    const columns = [

        {
            field: "id",
            headerName: "ID",
            width: 90
        },

        {
            field: "entityType",
            headerName: "Entity",
            flex: 1
        },

        {
            field: "entityId",
            headerName: "Entity ID",
            flex: 1
        },

        {
            field: "action",
            headerName: "Action",
            flex: 1
        },

        {
            field: "performedBy",
            headerName: "Performed By",
            flex: 1
        },

        {
            field: "timestamp",
            headerName: "Timestamp",
            flex: 1.5
        }

    ];

    return (

        <DashboardLayout>

            <Paper sx={{ p: 3 }}>

                <Typography
                    variant="h5"
                    mb={2}
                >

                    Audit Logs

                </Typography>

                <Box sx={{ height: 650 }}>

                    <DataGrid
                        rows={rows}
                        columns={columns}
                        pageSizeOptions={[10]}
                    />

                </Box>

            </Paper>

        </DashboardLayout>

    );

}