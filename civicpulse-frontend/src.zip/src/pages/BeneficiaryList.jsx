import { useEffect, useState } from "react";
import {
    Box,
    Button,
    Chip,
    Dialog,
    DialogActions,
    DialogContent,
    DialogTitle,
    MenuItem,
    Paper,
    Stack,
    TextField,
    Typography
} from "@mui/material";
import { DataGrid } from "@mui/x-data-grid";
import { toast } from "react-toastify";
import DashboardLayout from "../layouts/DashboardLayout";
import {
    getBeneficiaries,
    createBeneficiary,
    updateBeneficiary,
    deleteBeneficiary,
    verifyEligibility
} from "../services/beneficiaryService";

export default function BeneficiaryList() {

    const empty = {
        citizenId: "",
        schemeId: "",
        annualIncome: "",
        occupation: "",
        age: "",
        gender: ""
    };

    const [rows, setRows] = useState([]);
    const [open, setOpen] = useState(false);
    const [editing, setEditing] = useState(null);
    const [form, setForm] = useState(empty);

    const load = async () => {

        const res = await getBeneficiaries();

        setRows(res.data);

    };

    useEffect(() => {

        load();

    }, []);

    const save = async () => {

        try {

            if (editing)
                await updateBeneficiary(editing.id, form);
            else
                await createBeneficiary(form);

            toast.success("Saved");

            setOpen(false);
            setEditing(null);
            setForm(empty);

            load();

        } catch {

            toast.error("Operation Failed");

        }

    };

    const edit = (row) => {

        setEditing(row);

        setForm({
            citizenId: row.citizenId,
            schemeId: row.schemeId,
            annualIncome: row.annualIncome,
            occupation: row.occupation,
            age: row.age,
            gender: row.gender
        });

        setOpen(true);

    };

    const remove = async (id) => {

        await deleteBeneficiary(id);

        toast.success("Deleted");

        load();

    };

    const checkEligibility = async (id) => {

        const res = await verifyEligibility(id);

        toast.info(
            res.data ? "Eligible" : "Not Eligible"
        );

    };

    const columns = [

        {
            field: "id",
            headerName: "ID",
            width: 70
        },

        {
            field: "citizenId",
            headerName: "Citizen",
            flex: 1
        },

        {
            field: "schemeId",
            headerName: "Scheme",
            flex: 1
        },

        {
            field: "annualIncome",
            headerName: "Income",
            flex: 1
        },

        {
            field: "occupation",
            headerName: "Occupation",
            flex: 1
        },

        {
            field: "age",
            headerName: "Age",
            width: 90
        },

        {
            field: "gender",
            headerName: "Gender",
            width: 120
        },

        {
            field: "eligible",
            headerName: "Eligibility",
            width: 150,
            renderCell: (params) => (
                <Chip
                    label={
                        params.value
                            ? "Eligible"
                            : "Pending"
                    }
                    color={
                        params.value
                            ? "success"
                            : "warning"
                    }
                />
            )
        },

        {
            field: "actions",
            width: 280,
            renderCell: (params) => (

                <Stack
                    direction="row"
                    spacing={1}
                >

                    <Button
                        size="small"
                        variant="contained"
                        onClick={() => edit(params.row)}
                    >
                        Edit
                    </Button>

                    <Button
                        size="small"
                        color="success"
                        variant="contained"
                        onClick={() =>
                            checkEligibility(params.row.id)
                        }
                    >
                        Verify
                    </Button>

                    <Button
                        size="small"
                        color="error"
                        variant="contained"
                        onClick={() =>
                            remove(params.row.id)
                        }
                    >
                        Delete
                    </Button>

                </Stack>

            )
        }

    ];

    return (

        <DashboardLayout>

            <Paper sx={{ p: 3 }}>

                <Stack
                    direction="row"
                    justifyContent="space-between"
                    mb={2}
                >

                    <Typography variant="h5">

                        Beneficiaries

                    </Typography>

                    <Button
                        variant="contained"
                        onClick={() => {

                            setEditing(null);
                            setForm(empty);
                            setOpen(true);

                        }}
                    >

                        Add Beneficiary

                    </Button>

                </Stack>

                <Box sx={{ height: 620 }}>

                    <DataGrid
                        rows={rows}
                        columns={columns}
                        pageSizeOptions={[10]}
                    />

                </Box>

            </Paper>

            <Dialog
                open={open}
                onClose={() => setOpen(false)}
                fullWidth
                maxWidth="sm"
            >

                <DialogTitle>

                    {editing
                        ? "Edit Beneficiary"
                        : "New Beneficiary"}

                </DialogTitle>

                <DialogContent>

                    <Stack spacing={2} mt={1}>

                        <TextField
                            label="Citizen ID"
                            value={form.citizenId}
                            onChange={(e) =>
                                setForm({
                                    ...form,
                                    citizenId: e.target.value
                                })
                            }
                        />

                        <TextField
                            label="Scheme ID"
                            value={form.schemeId}
                            onChange={(e) =>
                                setForm({
                                    ...form,
                                    schemeId: e.target.value
                                })
                            }
                        />

                        <TextField
                            label="Annual Income"
                            type="number"
                            value={form.annualIncome}
                            onChange={(e) =>
                                setForm({
                                    ...form,
                                    annualIncome: e.target.value
                                })
                            }
                        />

                        <TextField
                            label="Occupation"
                            value={form.occupation}
                            onChange={(e) =>
                                setForm({
                                    ...form,
                                    occupation: e.target.value
                                })
                            }
                        />

                        <TextField
                            label="Age"
                            type="number"
                            value={form.age}
                            onChange={(e) =>
                                setForm({
                                    ...form,
                                    age: e.target.value
                                })
                            }
                        />

                        <TextField
                            select
                            label="Gender"
                            value={form.gender}
                            onChange={(e) =>
                                setForm({
                                    ...form,
                                    gender: e.target.value
                                })
                            }
                        >

                            <MenuItem value="MALE">
                                MALE
                            </MenuItem>

                            <MenuItem value="FEMALE">
                                FEMALE
                            </MenuItem>

                            <MenuItem value="OTHER">
                                OTHER
                            </MenuItem>

                        </TextField>

                    </Stack>

                </DialogContent>

                <DialogActions>

                    <Button
                        onClick={() =>
                            setOpen(false)
                        }
                    >
                        Cancel
                    </Button>

                    <Button
                        variant="contained"
                        onClick={save}
                    >
                        Save
                    </Button>

                </DialogActions>

            </Dialog>

        </DashboardLayout>

    );

}